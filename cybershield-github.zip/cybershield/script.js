const SC=[
{n:"Bank KYC alert",f:"Fear plus a lookalike bank domain",t:"URGENT! Your SBI bank account will be blocked today. Verify your KYC immediately: http://sbi-kyc-update.xyz/login"},
{n:"Parcel fee",f:"Small fee to capture card details",t:"Dear customer, your parcel delivery failed. Pay a customs fee of Rs 49 within 2 hours to avoid return: bit.ly/3xPackg"},
{n:"Electricity bill",f:"Disconnection threat with a short link",t:"Dear customer, your electricity will be disconnected tonight at 9:30 pm. Pay your pending bill immediately: bit.ly/kseb-pay"},
{n:"UPI refund",f:"Asks you to approve a payment request",t:"Refund of ₹4,999 is pending. Approve the collect request in your UPI app to receive it: http://refund-upi-help.top/claim"},
{n:"Prize link",f:"Reward bait sent to a raw IP address",t:"Congratulations! You have won a ₹50,000 reward. Claim now: http://192.168.44.12/claim?id=88"},
{n:"Genuine OTP",f:"Real banks warn you not to share codes",t:"482913 is your OTP for HDFC Bank transaction. Do not share this code with anyone."},
{n:"Genuine order",f:"Known name, official domain, no pressure",t:"Hi Asha, your Amazon order #402-1188 has shipped and will arrive Friday. Track it at https://www.amazon.in/orders"}];
const T=[
{k:"Urgent language",w:22,re:/\b(urgent(ly)?|immediately|right away|act now|within \d+ ?(minutes?|mins?|hours?)|expires? (today|soon)|tonight|last chance|final notice|asap|today only)\b/gi,t:"Pressure to act before you think."},
{k:"Threat of account loss",w:22,re:/\b(suspend(ed)?|block(ed)?|deactivat\w+|disconnect\w*|locked|terminated|restricted|unauthori[sz]ed|legal action|penalty)\b/gi,t:"Fear is a common phishing lever."},
{k:"Asks you to verify or log in",w:20,re:/\b(verify|confirm your|update your (kyc|details|account|pan|password)|re-?activate|log ?in|sign in|kyc|pan card)\b/gi,t:"Real banks rarely ask this by SMS or email."},
{k:"Asks you to approve a payment",w:25,re:/\b(collect request|approve (the |your )?(request|payment)|scan (the )?qr|enter (your )?upi pin)\b/gi,t:"Approving a request sends money out."},
{k:"Asks for sensitive details",w:25,re:/\b(password|cvv|card number|aadhaar|bank details|account number|share your (otp|pin))\b/gi,t:"Never share these with anyone."},
{k:"Reward or prize bait",w:22,re:/\b(you(?:'ve| have) won|winner|prize|reward|cashback|lottery|free gift|gift card|congratulations|claim (your|now))\b/gi,t:"Unexpected rewards are a classic lure."},
{k:"Fee or delivery wording",w:14,re:/\b(delivery failed|parcel|package|unpaid toll|customs fee|redelivery|pending bill)\b/gi,t:"Small fees are used to capture card details."},
{k:"Generic greeting",w:8,re:/\bdear (customer|user|member|client|account holder)\b/gi,t:"Genuine senders usually know your name."},
{k:"Financial context",w:8,re:/\b(bank|upi|refund|netbanking|credit card|debit card|wallet|income tax)\b/gi,t:"Money topics build false trust."}];
const LEGIT=/\b(do not share|never share|don'?t share|ignore if you)\b/gi;
const URL_RE=/\b((?:https?:\/\/|www\.)[^\s<>"]+|[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:com|net|org|in|co|xyz|top|click|info|link|live|online|site|icu|tk|ml|ga|cf|gq|ly|me|io|biz)(?:\/[^\s<>"]*)?)/gi;
const SHORT=["bit.ly","tinyurl.com","t.co","goo.gl","is.gd","cutt.ly","rb.gy","shorturl.at"],RT=["xyz","top","click","icu","tk","ml","ga","cf","gq","live","link","online","site"];
const BR={sbi:["sbi.co.in"],hdfc:["hdfcbank.com"],icici:["icicibank.com"],axis:["axisbank.com"],paypal:["paypal.com"],amazon:["amazon.in","amazon.com"],google:["google.com"],microsoft:["microsoft.com"],apple:["apple.com"],netflix:["netflix.com"],paytm:["paytm.com"],irctc:["irctc.co.in"]};
const esc=s=>s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function chk(u){const fl=[];let h="";
 try{h=new URL(/^https?:\/\//i.test(u)?u:"http://"+u).hostname.toLowerCase().replace(/^www\./,"")}catch(e){return{host:u,flags:[{l:"Address looks malformed",w:15}]}}
 const L=h.split("."),tld=L[L.length-1],lo=u.toLowerCase();
 if(SHORT.includes(h))fl.push({l:"Shortened link hides the real destination",w:25});
 if(/^\d{1,3}(\.\d{1,3}){3}$/.test(h))fl.push({l:"Raw IP address instead of a name",w:35});
 if(/^http:\/\//i.test(u))fl.push({l:"Not encrypted (http, not https)",w:12});
 if(RT.includes(tld))fl.push({l:"Uncommon ending (."+tld+") common in scams",w:20});
 if(/@/.test(lo.split("?")[0]))fl.push({l:"Contains @, which can disguise the site",w:25});
 if((h.match(/-/g)||[]).length>=2)fl.push({l:"Many hyphens in the domain",w:12});
 if(L.length>=4)fl.push({l:"Unusually many subdomains",w:12});
 if(h.includes("xn--"))fl.push({l:"Lookalike (punycode) characters",w:25});
 for(const b in BR){if(h.includes(b)&&!BR[b].some(d=>h===d||h.endsWith("."+d))){fl.push({l:"Mimics "+b.toUpperCase()+" but is not its official domain",w:30});break}}
 if(/(paypa1|amaz0n|g00gle|micr0soft)/.test(h))fl.push({l:"Lookalike spelling of a known brand",w:30});
 if(lo.length>75)fl.push({l:"Very long address",w:8});
 return{host:h,flags:fl}}
function analyze(x){const rg=[],fd=[],lk=[];let raw=0;
 T.forEach(f=>{const m=[...x.matchAll(f.re)];if(m.length){fd.push({l:f.k,w:f.w,t:f.t,h:[...new Set(m.map(a=>a[0].toLowerCase()))].slice(0,3)});raw+=f.w;m.forEach(a=>rg.push([a.index,a.index+a[0].length]))}});
 if([...x.matchAll(LEGIT)].length){fd.push({l:"Warns you not to share codes",w:-18,t:"Genuine senders add this reminder.",h:[]});raw-=18}
 const seen=new Set();
 [...x.matchAll(URL_RE)].forEach(m=>{const u=m[0].replace(/[.,;)]+$/,"");rg.push([m.index,m.index+u.length]);if(seen.has(u))return;seen.add(u);const r=chk(u);lk.push(r);raw+=Math.min(60,r.flags.reduce((a,f)=>a+f.w,0))});
 if(lk.length&&fd.some(f=>f.w>=20))raw+=10;
 return{risk:raw<=0?2:Math.min(99,Math.max(3,Math.round(100*(1-Math.exp(-raw/45))))),fd,lk,rg}}
function hl(t,r){const s=r.slice().sort((a,b)=>a[0]-b[0]),m=[];s.forEach(x=>{const l=m[m.length-1];if(l&&x[0]<=l[1])l[1]=Math.max(l[1],x[1]);else m.push([x[0],x[1]])});let o="",p=0;m.forEach(([a,b])=>{o+=esc(t.slice(p,a))+"<mark>"+esc(t.slice(a,b))+"</mark>";p=b});return o+esc(t.slice(p))}
const KT=[["Fear","Fake domain","Urgency"],["Fee bait","Short link","Urgency"],["Fear","Short link","Urgency"],["Payment trap","Fake domain"],["Reward bait","IP address"],["Warns about sharing","Known sender"],["Known name","Official domain"]];
const V={safe:["Low risk","Looks safe","No strong phishing signs found. If it asks you to do anything, open the official app yourself."],
 risky:["Suspicious","Treat with care","Do not tap the link. Confirm the claim through the official website or app, or the number on your card."],
 bad:["Phishing","Phishing detected","Do not click or reply, and never share codes. Verify via the official app, then report and delete it."]};
let H=[];try{H=JSON.parse(localStorage.getItem("cs_h")||"[]")}catch(e){}
const $=id=>document.getElementById(id);
function stats(){$("s1").textContent=H.length;$("s2").textContent=H.filter(h=>h.r>=30).length;$("s3").textContent=(H.length?Math.max(...H.map(h=>h.r)):0)+"%";
 $("hist").innerHTML=H.length?H.slice(0,6).map((h,i)=>`<li data-i="${i}"><em class="${h.c}">${h.r}%</em><span>${esc(h.t)}</span></li>`).join(""):'<li style="cursor:default;color:var(--mute)">Your scans will appear here.</li>';
 $("hist").querySelectorAll("li[data-i]").forEach(li=>li.onclick=()=>{$("inp").value=H[li.dataset.i].t;run(false)})}
let last="";
function run(save=true){const t=$("inp").value;
 if(!t.trim()){$("rep").innerHTML='<div class="empty">Paste a message or link, then select Analyze.</div>';return}
 const a=analyze(t),c=a.risk<30?"safe":a.risk<65?"risky":"bad",v=V[c];
 if(save){H.unshift({t:t,r:a.risk,c:c});H=H.slice(0,20);try{localStorage.setItem("cs_h",JSON.stringify(H))}catch(e){}stats()}
 let h=`<div class="top"><div class="gauge"><svg viewBox="0 0 220 120"><path class="tr" d="M20 110 A90 90 0 0 1 200 110" pathLength="100"/><path class="fl ${c}" id="fl" stroke="currentColor" d="M20 110 A90 90 0 0 1 200 110" pathLength="100" style="stroke-dasharray:0 100"/></svg><div class="n ${c}">${a.risk}%</div></div><div class="vt"><span class="stamp ${c}">${v[0]}</span><p>${v[1]}. Risk scale: under 30 safe, 30 to 64 suspicious, 65 and above phishing.</p></div></div>`;
 const sm=(r)=>a.fd.filter(f=>r.test(f.l)&&f.w>0).reduce((q,f)=>q+f.w,0);
 const P=sm(/Urgent|Threat/),D=sm(/^(?!Urgent|Threat|Financial)/),K=a.lk.reduce((q,l)=>q+l.flags.reduce((z,f)=>z+f.w,0),0),X=sm(/Financial/),tt=P+D+K+X;
 if(tt>0){const sg=[["Pressure",P,"var(--risky)"],["Deception",D,"var(--bad)"],["Link risk",K,"var(--acc)"],["Context",X,"var(--mute)"]].filter(z=>z[1]>0);
  h+=`<h3 class="s">Where the risk comes from</h3><div class="sb">${sg.map(z=>`<i style="flex:${z[1]};background:${z[2]}"></i>`).join("")}</div><div class="lg">${sg.map(z=>`<span style="--c:${z[2]}">${z[0]} ${Math.round(z[1]/tt*100)}%</span>`).join("")}</div>`}
 h+=`<h3 class="s">Why this score</h3><p style="margin:-4px 0 6px;font-size:13px;color:var(--mute)">${a.fd.filter(f=>f.w>0).length} of 9 wording checks and ${a.lk.reduce((q,l)=>q+l.flags.length,0)} link flags triggered.</p>`;
 if(!a.fd.length&&!a.lk.length)h+='<p style="color:var(--mute);font-size:14px">No phishing indicators found in the wording.</p>';
 a.fd.forEach(f=>{h+=`<div class="f"><div><b>${esc(f.l)}</b>${f.h.length?` <small style="display:inline">(${f.h.map(esc).join(", ")})</small>`:""}<small>${esc(f.t)}</small></div><div class="bar ${f.w<0?"g":""}"><i style="width:${Math.min(100,Math.abs(f.w)/30*100)}%"></i></div><div class="v ${f.w<0?"safe":"bad"}">${f.w>0?"+":""}${f.w}</div></div>`});
 if(a.lk.length){h+='<h3 class="s">Link check</h3>';a.lk.forEach(l=>{h+=`<div class="lk"><code>${esc(l.host)}</code>${l.flags.length?l.flags.map(f=>`<div>+${f.w} · ${esc(f.l)}</div>`).join(""):"<div>No red flags in this address.</div>"}</div>`})}
 h+=`<h3 class="s">Marked in your message</h3><div class="msg">${hl(t,a.rg)}</div><div class="rec ${c}"><b>Recommendation</b><span>${v[2]}</span></div><div class="row"><button id="cp">Copy report</button><button onclick="window.print()">Print</button></div>`;
 $("rep").innerHTML=h;
 last=`CyberShield report\nRisk: ${a.risk}% (${v[1]})\nReasons: ${a.fd.map(f=>f.l).join("; ")||"none"}\nLinks: ${a.lk.map(l=>l.host).join(", ")||"none"}\nAdvice: ${v[2]}`;
 $("cp").onclick=async()=>{try{await navigator.clipboard.writeText(last);$("cp").textContent="Copied"}catch(e){$("cp").textContent="Copy not available here"}};
 requestAnimationFrame(()=>requestAnimationFrame(()=>{const f=$("fl");if(f)f.style.strokeDasharray=a.risk+" 100"}))}
$("cards").innerHTML=SC.map((s,i)=>`<div class="card sc"><span class="tag ${i>4?"safe":"bad"}">${i>4?"Genuine":"Scam"}</span><b>${s.n}</b><p>${s.f}.</p><div>${KT[i].map(k=>`<span class="chip">${k}</span>`).join("")}</div><button data-c="${i}">Analyze this</button></div>`).join("");
document.querySelectorAll("[data-c]").forEach(b=>b.onclick=()=>{$("inp").value=SC[b.dataset.c].t;run();window.scrollTo({top:0})});
$("go").onclick=()=>run();$("clr").onclick=()=>{$("inp").value="";run(false);$("inp").focus()};
$("inp").addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key==="Enter")run()});

$("inp").value=SC[0].t;stats();run(false);
