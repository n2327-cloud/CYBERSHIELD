# CyberShield

AI-assisted phishing detection and risk analysis. Paste a message or link to get a risk score, the reasons behind it, and a recommended action.

## Files
- `index.html` - page structure
- `style.css` - design
- `script.js` - scoring logic (wording rules and link checks)

## Run locally
Open `index.html` in a browser.

## Note
This version scores messages with weighted rules, not a trained ML model.
